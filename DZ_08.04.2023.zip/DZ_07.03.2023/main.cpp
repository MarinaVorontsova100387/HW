//Воронцова Марина Александровна
//Задание срок 07.03.2022


#include <iostream>


int main() {

    system("chcp 65001");



    std::cout << "\n Добрый день! Ознакомилась." << std::endl;

    return 0;
}
